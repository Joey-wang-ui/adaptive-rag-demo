"""Jiahui assistant: transport-independent business gateway."""

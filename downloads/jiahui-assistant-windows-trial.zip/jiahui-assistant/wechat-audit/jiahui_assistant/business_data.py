"""Read-only, timestamped price/stock snapshots; never update an ERP."""

import re
from datetime import UTC, datetime, timedelta
from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field


class Product(BaseModel):
    model_config = ConfigDict(extra="forbid")
    code: str = Field(min_length=1, max_length=100)
    name: str = Field(min_length=1, max_length=200)
    specification: str = Field(min_length=1, max_length=200)
    unit_price: Decimal | None = Field(default=None, ge=0, allow_inf_nan=False)
    price_unit: str = Field(default="", max_length=30)
    stock: Decimal | None = Field(default=None, ge=0, allow_inf_nan=False)
    stock_unit: str = Field(default="", max_length=30)


class Snapshot(BaseModel):
    model_config = ConfigDict(extra="forbid")
    updated_at: datetime
    source: str = Field(min_length=1, max_length=500)
    products: list[Product] = Field(min_length=1, max_length=1000)

    def answer(self, question, now=None):
        now = now or datetime.now(UTC)
        if self.updated_at.tzinfo is None:
            return "业务数据缺少时区，无法判断更新时间，请重新导入。"
        age = now - self.updated_at
        if age > timedelta(hours=24) or age < -timedelta(minutes=5):
            return (
                f"业务数据已过期或时间异常（{self.updated_at.isoformat()}），不提供价格或库存结论。"
            )
        hits = [
            p
            for p in self.products
            if re.search(r"(?<![A-Za-z0-9_-])" + re.escape(p.code) + r"(?![A-Za-z0-9_-])", question)
            or p.name in question
        ]
        if len(hits) != 1:
            return "请提供能唯一匹配的商品编码或名称及规格，未给出推测价格或库存。"
        product = hits[0]
        price = (
            f"{product.unit_price}元/{product.price_unit}"
            if product.unit_price is not None and product.price_unit
            else "未提供"
        )
        stock = (
            f"{product.stock}{product.stock_unit}"
            if product.stock is not None and product.stock_unit
            else "未提供"
        )
        return (
            f"{product.code} {product.name}｜{product.specification}\n"
            f"价格：{price}\n库存：{stock}\n"
            f"更新时间：{self.updated_at.isoformat()}\n来源：{self.source}\n"
            "这是已导入数据的只读副本，不保证此刻未发生变化；成交和可发数量请人工确认。"
        )

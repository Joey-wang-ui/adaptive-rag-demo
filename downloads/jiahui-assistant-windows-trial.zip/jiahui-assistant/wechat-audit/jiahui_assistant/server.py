"""Authenticated loopback console and AstrBot gateway."""

import asyncio
import hmac
import os
import secrets
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, SecretStr
from shipment_bot.extract import ExtractionError

from jiahui_assistant.business_data import Snapshot
from jiahui_assistant.core import Assistant, Message, Settings, make_extractor


class ModelKey(BaseModel):
    api_key: SecretStr = Field(min_length=1, max_length=1000)


def create_app(assistant, token):
    if len(token) < 32:
        raise ValueError("A private gateway token of at least 32 characters is required")
    app = FastAPI(title="嘉惠业务助手", docs_url=None, redoc_url=None, openapi_url=None)

    async def authorize(authorization: str = Header(default="")):
        if not hmac.compare_digest(authorization, "Bearer " + token):
            raise HTTPException(401, "Unauthorized")

    @app.get("/")
    async def console():
        return FileResponse(Path(__file__).with_name("console.html"))

    @app.get("/health")
    async def health():
        return {"ok": True, "service": "jiahui-assistant"}

    @app.get("/status", dependencies=[Depends(authorize)])
    async def status():
        return await asyncio.to_thread(assistant.status)

    @app.put("/settings", dependencies=[Depends(authorize)])
    async def settings(value: Settings):
        try:
            await asyncio.to_thread(assistant.configure, value)
        except ValueError as error:
            raise HTTPException(400, str(error)) from None
        return assistant.status()

    @app.post("/pending/clear", dependencies=[Depends(authorize)])
    async def clear():
        await asyncio.to_thread(assistant.clear_pending)
        return {"ok": True}

    @app.post("/stop", dependencies=[Depends(authorize)])
    async def stop():
        await asyncio.to_thread(assistant.stop)
        return {"ok": True}

    @app.put("/model", dependencies=[Depends(authorize)])
    async def model(value: ModelKey):
        key = value.api_key.get_secret_value().strip()
        if not key:
            raise HTTPException(400, "Key 不能为空。")
        with assistant.lock:
            path = assistant.directory / "deepseek-key.txt"
            path.write_text(key, encoding="utf-8")
            path.chmod(0o600)
            assistant.extractor = make_extractor(key)
        return {"ok": True, "notice": "已保存到本机；尚未调用 API 验证。"}

    @app.put("/business-data", dependencies=[Depends(authorize)])
    async def business_data(value: Snapshot):
        if value.updated_at.tzinfo is None:
            raise HTTPException(400, "更新时间必须带时区。")
        if len({product.code for product in value.products}) != len(value.products):
            raise HTTPException(400, "商品编码重复。")
        path = assistant.directory / "business-data.json"
        with assistant.lock:
            temporary = path.with_suffix(".tmp")
            temporary.write_text(value.model_dump_json(), encoding="utf-8")
            temporary.replace(path)
        return {"ok": True, "notice": "已导入只读副本，没有修改库存或财务系统。"}

    @app.post("/message", dependencies=[Depends(authorize)])
    async def message(value: Message):
        try:
            reply = await asyncio.to_thread(assistant.handle, value)
            return {"reply": reply}
        except ExtractionError:
            return {
                "reply": "【嘉惠业务助手】图片或文字提取未完成，请检查原图后重新 @审核。未批准发货。"
            }
        except Exception:
            # Never expose paths, document contents, provider responses or secrets.
            return {"reply": "【嘉惠业务助手】处理失败，请检查本机配置后重新 @审核。未批准发货。"}

    return app


def main():
    import uvicorn

    directory = Path(
        os.environ.get("JIAHUI_DATA_DIR", Path(__file__).resolve().parents[1] / "data/assistant")
    )
    directory.mkdir(parents=True, exist_ok=True)
    token_file = directory / "gateway-token.txt"
    if not token_file.exists():
        token_file.write_text(secrets.token_urlsafe(40), encoding="utf-8")
        token_file.chmod(0o600)
    token = token_file.read_text(encoding="utf-8").strip()
    roots = [x for x in os.environ.get("JIAHUI_MEDIA_ROOTS", "").split(os.pathsep) if x]
    key_file = directory / "deepseek-key.txt"
    key = os.environ.get("DEEPSEEK_API_KEY", "")
    if not key and key_file.exists():
        key = key_file.read_text(encoding="utf-8").strip()
    assistant = Assistant(
        directory,
        roots,
        extractor=make_extractor(key),
        rag_url=os.environ.get("JIAHUI_RAG_URL", ""),
        rag_token=os.environ.get("JIAHUI_RAG_TOKEN", ""),
    )
    print("嘉惠业务助手控制台已启动（仅本机）。默认关闭真实消息处理。", flush=True)
    print(
        "网关令牌保存在 data/assistant/gateway-token.txt；只在本机控制台和 AstrBot 插件填写，不发到聊天。",
        flush=True,
    )
    uvicorn.run(create_app(assistant, token), host="127.0.0.1", port=18960, access_log=False)


if __name__ == "__main__":
    main()

"""Persistent, group-scoped workflow; no desktop control or shipping approval."""

import hashlib
import json
import re
import sqlite3
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit

import httpx
from PIL import Image
from pydantic import BaseModel, ConfigDict, Field
from shipment_bot.auto_review import Recognized, summarize
from shipment_bot.extract import ExtractionError, Extractor, validate_image
from shipment_bot.group_audit import looks_like_document

from jiahui_assistant.business_data import Snapshot

PREFIX = "【嘉惠业务助手】"


class Message(BaseModel):
    model_config = ConfigDict(extra="forbid")
    platform: str = Field(min_length=1, max_length=100)
    group: str = Field(default="", max_length=200)
    sender: str = Field(min_length=1, max_length=200)
    self_id: str = Field(min_length=1, max_length=200)
    message_id: str = Field(min_length=1, max_length=250)
    mentioned: bool = False
    text: str = Field(default="", max_length=20000)
    images: list[str] = Field(default_factory=list, max_length=4)


class Settings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool = False
    platform: str = Field(default="", max_length=100)
    group: str = Field(default="", max_length=200)
    mode: str = Field(default="text_test", pattern="^(text_test|image_test|business)$")
    text_verified: bool = False
    original_verified: bool = False
    knowledge_ready: bool = False


class Assistant:
    """Serialize processing and persist retries, parsed materials and completed batches."""

    def __init__(
        self, directory, media_roots, *, extractor=None, rag_url="", rag_token="", clock=time.time
    ):
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.roots = [Path(root) for root in media_roots]
        self.extractor = extractor
        self.rag_url = rag_url
        if rag_url:
            url = urlsplit(rag_url)
            if (
                url.scheme != "http"
                or url.hostname not in {"127.0.0.1", "localhost", "::1"}
                or url.username
                or url.password
                or url.query
                or url.fragment
                or not url.path.endswith("/jiahui/query")
            ):
                raise ValueError(
                    "知识查询必须使用本机只读 /jiahui/query 接口，不能使用通用 /chat 接口。"
                )
        self.rag_token = rag_token
        self.clock = clock
        self.lock = threading.RLock()
        self.paused = threading.Event()
        self.path = self.directory / "assistant.sqlite3"
        with self.connect() as db:
            db.executescript("""
                CREATE TABLE IF NOT EXISTS settings(id INTEGER PRIMARY KEY, value TEXT);
                CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS materials(
                    scope TEXT, digest TEXT, payload TEXT, parsed TEXT, created REAL,
                    PRIMARY KEY(scope,digest));
                CREATE TABLE IF NOT EXISTS completed(scope TEXT, fingerprint TEXT,
                    PRIMARY KEY(scope,fingerprint));
                CREATE TABLE IF NOT EXISTS evidence(kind TEXT PRIMARY KEY, detail TEXT);
            """)
        self.settings = self.load_settings()
        if not self.settings.enabled:
            self.paused.set()

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        try:
            with db:
                yield db
        finally:
            db.close()

    def load_settings(self):
        with self.connect() as db:
            row = db.execute("SELECT value FROM settings WHERE id=1").fetchone()
        return Settings.model_validate_json(row[0]) if row else Settings()

    def configure(self, settings):
        with self.lock:
            previous = self.settings
            # Changing transport identity invalidates every manual verification.
            if (settings.platform, settings.group) != (previous.platform, previous.group):
                settings.text_verified = settings.original_verified = False
                settings.mode = "text_test"
            if settings.enabled and (not settings.platform or not settings.group):
                raise ValueError("先填写精确的平台实例 ID 和测试群 ID。")
            if settings.mode != "text_test" and not settings.text_verified:
                raise ValueError("先实测群内 @ 文字回复，再确认文字链路通过。")
            if settings.mode == "business" and not settings.original_verified:
                raise ValueError("先完成原图接收测试，再启用业务模式。")
            with self.connect() as db:
                if (settings.platform, settings.group) != (previous.platform, previous.group):
                    db.execute("DELETE FROM evidence")
                db.execute(
                    "INSERT OR REPLACE INTO settings VALUES (1,?)", (settings.model_dump_json(),)
                )
            self.settings = settings
            if settings.enabled:
                self.paused.clear()
            else:
                self.paused.set()

    def stop(self):
        """Block new work immediately; an in-flight request is not cancelled."""
        self.paused.set()
        settings = self.settings.model_copy(update={"enabled": False})
        with self.connect() as db:
            db.execute(
                "INSERT OR REPLACE INTO settings VALUES (1,?)", (settings.model_dump_json(),)
            )
        self.settings = settings

    def status(self):
        with self.lock, self.connect() as db:
            evidence = dict(db.execute("SELECT kind,detail FROM evidence").fetchall())
            return {
                "settings": self.settings.model_dump(),
                "evidence": evidence,
                "model_configured": self.extractor is not None,
                "rag_configured": bool(self.rag_url),
                "notice": "软件测试不等于真实普通微信群接入成功；业务数据不会自动批准发货。",
            }

    @staticmethod
    def digest(value):
        return hashlib.sha256(
            json.dumps(value, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()

    def handle(self, message):
        with self.lock:
            s = self.settings
            if (
                self.paused.is_set()
                or not s.enabled
                or not message.group
                or message.platform != s.platform
                or message.group != s.group
                or message.sender == message.self_id
                or message.text.startswith(PREFIX)
            ):
                return None
            event = self.digest([message.platform, message.group, message.message_id])
            with self.connect() as db:
                if db.execute("SELECT 1 FROM events WHERE id=?", (event,)).fetchone():
                    return None
            if s.mode == "text_test":
                if not message.mentioned or message.text.strip() != "测试":
                    return None
                with self.connect() as db:
                    db.execute(
                        "INSERT OR REPLACE INTO evidence VALUES ('text',?)",
                        ("已处理测试请求；请在真实群内确认收到回复。",),
                    )
                reply = "测试成功：已收到指定群内的 @ 测试消息。"
            elif s.mode == "image_test":
                if not message.mentioned or not message.images:
                    return None
                details = []
                for source in message.images:
                    path = validate_image(Path(source), self.roots)
                    with Image.open(path) as image:
                        width, height = image.size
                    digest = hashlib.sha256(path.read_bytes()).hexdigest()
                    details.append(f"{width}×{height}，{path.stat().st_size}字节，SHA256 {digest}")
                reply = "已接收图片（未调用模型）：\n" + "\n".join(details)
                reply += "\n请与发送端原文件比对；能收到图片不等于已取得原图。"
                with self.connect() as db:
                    db.execute("INSERT OR REPLACE INTO evidence VALUES ('image',?)", (reply,))
            else:
                reply = self.business(message)
            if reply:
                # Persist before returning: delivery uncertainty must never cause a replay loop.
                with self.connect() as db:
                    db.execute("INSERT OR IGNORE INTO events VALUES (?)", (event,))
                return PREFIX + "\n" + reply
            return None

    def business(self, message):
        text = message.text.strip()
        if message.mentioned and text.startswith("查询"):
            return self.query(text[2:].strip(), message)
        scope = self.digest([message.platform, message.group, message.sender])
        requested = message.mentioned and bool(
            re.match(r"^(?:请)?(?:帮我)?(?:审核|审单|检查|看看|看下)", text)
        )
        body = (
            re.sub(r"^(?:请)?(?:帮我)?(?:审核|审单|检查|看看|看下)[：:\s]*", "", text)
            if requested
            else text
        )
        payloads = []
        if body and (requested or looks_like_document(body)):
            payloads.append({"text": body})
        # No OCR or model invocation occurs during collection.
        for source in message.images:
            path = validate_image(Path(source), self.roots)
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            destination = self.directory / "media" / (digest + path.suffix.lower())
            destination.parent.mkdir(exist_ok=True)
            if not destination.exists():
                destination.write_bytes(path.read_bytes())
            payloads.append({"image": str(destination), "sha256": digest})
        with self.connect() as db:
            db.execute("DELETE FROM materials WHERE created<?", (self.clock() - 600,))
            existing = db.execute(
                "SELECT digest FROM materials WHERE scope=? ORDER BY digest", (scope,)
            ).fetchall()
            existing_ids = [row[0] for row in existing]
            # Start a new batch only for genuinely new material, retaining completed fingerprints.
            completed = db.execute(
                "SELECT 1 FROM completed WHERE scope=? AND fingerprint=?",
                (scope, self.digest(existing_ids)),
            ).fetchone()
            if completed and any(self.digest(payload) not in existing_ids for payload in payloads):
                db.execute("DELETE FROM materials WHERE scope=?", (scope,))
            for payload in payloads:
                db.execute(
                    "INSERT OR IGNORE INTO materials VALUES (?,?,?,NULL,?)",
                    (
                        scope,
                        self.digest(payload),
                        json.dumps(payload, ensure_ascii=False),
                        self.clock(),
                    ),
                )
        if not requested:
            return None
        with self.connect() as db:
            rows = db.execute(
                "SELECT digest,payload,parsed FROM materials WHERE scope=? ORDER BY digest",
                (scope,),
            ).fetchall()
        if not rows:
            return "请发送订单文字或单据图片，再 @我 审核。材料只关联同一发送者的近期消息。"
        if len(rows) > 4:
            return "近期材料超过4份，未调用模型。请在控制台清空待审材料后分批发送。"
        fingerprint = self.digest([row[0] for row in rows])
        with self.connect() as db:
            if db.execute(
                "SELECT 1 FROM completed WHERE scope=? AND fingerprint=?", (scope, fingerprint)
            ).fetchone():
                return None
        if self.extractor is None:
            return "尚未在本机配置 DeepSeek API Key；未进行审核。不要在群里发送密钥。"
        items, errors = [], []
        for index, (digest, payload, parsed) in enumerate(rows, 1):
            try:
                if parsed:
                    item = Recognized.model_validate_json(parsed)
                else:
                    raw = json.loads(payload)
                    item = (
                        self.extractor.auto_text(raw["text"])
                        if "text" in raw
                        else self.extractor.auto_image(Path(raw["image"]))
                    )
                    if len(item.document.lines) > 30:
                        raise ExtractionError("单份材料超过30行，请拆单。")
                    with self.connect() as db:
                        db.execute(
                            "UPDATE materials SET parsed=? WHERE scope=? AND digest=?",
                            (item.model_dump_json(), scope, digest),
                        )
                item.image_index = index
                items.append(item)
            except ExtractionError as error:
                errors.append(f"第{index}份材料：{error}")
        if not errors:
            with self.connect() as db:
                db.execute("INSERT OR IGNORE INTO completed VALUES (?,?)", (scope, fingerprint))
        return summarize(items, errors, require_customer=True, require_specification=True)

    def query(self, question, message):
        if not question:
            return "请在“查询”后填写产品或业务规则问题。"
        if re.search(r"价格|单价|报价|库存|现货|多少钱|有货", question):
            snapshot = self.directory / "business-data.json"
            if snapshot.exists():
                try:
                    return Snapshot.model_validate_json(
                        snapshot.read_text(encoding="utf-8")
                    ).answer(question)
                except ValueError:
                    return "业务数据格式无效，未提供价格或库存结论。"
            return "价格和库存需要有更新时间的业务数据。目前尚未接入，不根据目录或模型记忆报价。"
        if not self.settings.knowledge_ready or not self.rag_url:
            return "嘉惠知识库尚未验收。产品目录和公司规则未导入前，不使用原电商示例资料回答。"
        with httpx.Client(timeout=90, follow_redirects=False) as client:
            response = client.post(
                self.rag_url,
                headers={"Authorization": "Bearer " + self.rag_token},
                json={"message": question[:4000]},
            )
            response.raise_for_status()
            result = response.json()
        if result.get("pending_action") or result.get("error_code") or not result.get("citations"):
            return "未取得可引用的嘉惠资料，未给出业务结论，也未确认任何写入操作。"
        sources = [
            f"{x['title']}｜{x.get('section') or x['chunk_id']}" for x in result["citations"]
        ]
        return result["answer"] + "\n来源：\n" + "\n".join(sources)

    def clear_pending(self):
        with self.lock, self.connect() as db:
            db.execute("DELETE FROM materials")
            for path in (self.directory / "media").glob("*"):
                if re.fullmatch(r"[0-9a-f]{64}\.[a-zA-Z0-9]+", path.name) and path.is_file():
                    path.unlink()


def make_extractor(key):
    return Extractor(key) if key else None

"""End-to-end local gateway tests with fake model and no WeChat connection."""

import threading
from datetime import UTC, datetime, timedelta
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest
from jiahui_assistant.business_data import Snapshot
from jiahui_assistant.core import Assistant, Message, Settings
from jiahui_assistant.server import create_app
from PIL import Image
from shipment_bot.auto_review import Recognized
from shipment_bot.extract import ExtractionError
from shipment_bot.models import Document, Line


def recognized():
    return Recognized(
        kind="delivery",
        document=Document(
            customer="虚构测试店",
            document_number="TEST-1",
            total="100",
            lines=[
                Line(
                    name="测试商品",
                    specification="测试规格",
                    quantity="2",
                    unit="箱",
                    price_unit="箱",
                    unit_price="50",
                    amount="100",
                )
            ],
        ),
    )


@pytest.fixture
def assistant(tmp_path):
    model = SimpleNamespace(
        auto_text=Mock(side_effect=lambda _: recognized()),
        auto_image=Mock(side_effect=lambda _: recognized()),
    )
    return Assistant(tmp_path / "data", [tmp_path], extractor=model, clock=lambda: 1000)


def enable(assistant, mode="business"):
    assistant.configure(Settings(enabled=True, platform="wx", group="test-group"))
    assistant.configure(
        Settings(
            enabled=True,
            platform="wx",
            group="test-group",
            mode=mode,
            text_verified=True,
            original_verified=True,
        )
    )


def message(number="1", **changes):
    return Message(
        **(
            {
                "platform": "wx",
                "group": "test-group",
                "sender": "member",
                "self_id": "bot",
                "message_id": number,
                "text": "审核",
                "mentioned": True,
            }
            | changes
        )
    )


def test_disabled_by_default_and_stage_gates(assistant):
    assert assistant.handle(message()) is None
    assistant.configure(Settings(enabled=True, platform="wx", group="test-group"))
    with pytest.raises(ValueError):
        assistant.configure(
            Settings(enabled=True, platform="wx", group="test-group", mode="business")
        )
    assert assistant.handle(message(text="测试")).endswith("@ 测试消息。")
    assert assistant.handle(message(text="测试")) is None
    assert not assistant.settings.text_verified


@pytest.mark.parametrize(
    "changes",
    [
        {"group": ""},
        {"group": "other"},
        {"platform": "qq"},
        {"sender": "bot"},
        {"text": "【嘉惠业务助手】审核"},
    ],
)
def test_scope_stays_silent(assistant, changes):
    enable(assistant)
    assert assistant.handle(message(**changes)) is None
    assistant.extractor.auto_text.assert_not_called()


def test_material_collection_is_silent_and_persistent_dedup(assistant):
    enable(assistant)
    assert (
        assistant.handle(
            message("1", text="客户测试店 商品2箱 单价50元 金额100元", mentioned=False)
        )
        is None
    )
    assistant.extractor.auto_text.assert_not_called()
    assert "行金额及合计未发现" in assistant.handle(message("2"))
    assert assistant.handle(message("3")) is None
    restarted = Assistant(
        assistant.directory, assistant.roots, extractor=assistant.extractor, clock=lambda: 1000
    )
    assert restarted.handle(message("4")) is None
    assert assistant.extractor.auto_text.call_count == 1
    assert restarted.handle(message("5", text="审核\n客户另一个店 商品3箱"))
    assert assistant.extractor.auto_text.call_count == 2


def test_failed_image_retries_without_reparsing_successful_text(assistant, tmp_path):
    enable(assistant)
    path = tmp_path / "image.png"
    Image.new("RGB", (200, 100), "white").save(path)
    assistant.handle(message("1", text="商品2箱", mentioned=False))
    assistant.handle(message("2", text="", images=[str(path)], mentioned=False))
    assistant.extractor.auto_image.side_effect = ExtractionError("识别失败")
    assert "识别失败" in assistant.handle(message("3"))
    assistant.extractor.auto_image.side_effect = lambda _: recognized()
    assert "识别失败" not in assistant.handle(message("4"))
    assert assistant.extractor.auto_text.call_count == 1
    assert assistant.handle(message("5")) is None


def test_image_probe_never_calls_model_or_claims_original(assistant, tmp_path):
    enable(assistant, "image_test")
    path = tmp_path / "image.png"
    Image.new("RGB", (800, 600), "white").save(path)
    reply = assistant.handle(message(images=[str(path)]))
    assert "800×600" in reply and "SHA256" in reply and "不等于已取得原图" in reply
    assistant.extractor.auto_image.assert_not_called()
    outside = Assistant(tmp_path / "other", [], clock=lambda: 1000)
    enable(outside, "image_test")
    with pytest.raises(ExtractionError):
        outside.handle(message(images=[str(path)]))


def test_ordinary_chat_never_calls_model_and_stop_survives_restart(assistant):
    enable(assistant)
    assert assistant.handle(message(text="今天天气如何", mentioned=False)) is None
    assert assistant.handle(message("2", text="今天天气如何")) is None
    assistant.stop()
    assert assistant.handle(message("3", text="审核 商品2箱")) is None
    assert not Assistant(assistant.directory, []).settings.enabled


def test_no_ecommerce_fallback_and_no_price_guessing(assistant):
    enable(assistant)
    assert "电商示例" in assistant.handle(message(text="查询 产品规格"))
    assert "更新时间" in assistant.handle(message("2", text="查询 库存"))


def test_change_group_resets_verification(assistant):
    enable(assistant)
    assistant.configure(assistant.settings.model_copy(update={"group": "new"}))
    assert assistant.settings.mode == "text_test"
    assert not assistant.settings.original_verified


def test_stop_does_not_wait_for_model_lock(assistant):
    enable(assistant)
    started, release = threading.Event(), threading.Event()

    def waiting(_):
        started.set()
        assert release.wait(5)
        return recognized()

    assistant.extractor.auto_text.side_effect = waiting
    worker = threading.Thread(target=assistant.handle, args=(message(text="审核 商品2箱"),))
    worker.start()
    try:
        assert started.wait(5)
        assistant.stop()
        assert assistant.paused.is_set()
    finally:
        release.set()
        worker.join(5)
    assert assistant.handle(message("2", text="审核 商品3箱")) is None


@pytest.mark.asyncio
async def test_authenticated_console_model_and_message(assistant):
    token = "a" * 40
    headers = {"Authorization": "Bearer " + token}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=create_app(assistant, token)), base_url="http://local"
    ) as client:
        assert (await client.get("/health")).json()["ok"]
        assert (await client.get("/status")).status_code == 401
        assert (await client.put("/settings", json={})).status_code == 401
        assert (await client.post("/message", json=message().model_dump())).status_code == 401
        assert (
            await client.put("/model", json={"api_key": "test-only"}, headers=headers)
        ).status_code == 200
        result = await client.get("/status", headers=headers)
        assert "test-only" not in result.text
        assert result.json()["model_configured"]
        assert (await client.post("/stop", headers=headers)).status_code == 200
        assert (await client.post("/pending/clear", headers=headers)).status_code == 200
        bad = {
            "updated_at": "2026-10-31T12:00:00",
            "source": "自动测试",
            "products": [{"code": "TEST", "name": "虚构商品", "specification": "虚构规格"}],
        }
        assert (await client.put("/business-data", json=bad, headers=headers)).status_code == 400
        bad["updated_at"] += "+08:00"
        assert (await client.put("/business-data", json=bad, headers=headers)).status_code == 200
        bad["products"].append(bad["products"][0])
        assert (await client.put("/business-data", json=bad, headers=headers)).status_code == 400


def test_business_snapshot_never_uses_old_or_ambiguous_data():
    now = datetime.now(UTC)
    snapshot = Snapshot(
        updated_at=now,
        source="自动测试专用数据，非嘉惠价格",
        products=[
            {
                "code": "TEST-1",
                "name": "虚构商品",
                "specification": "虚构规格",
                "unit_price": "1.25",
                "price_unit": "箱",
                "stock": "2",
                "stock_unit": "箱",
            }
        ],
    )
    assert "1.25元/箱" in snapshot.answer("TEST-1 价格", now)
    assert "只读副本" in snapshot.answer("虚构商品 库存", now)
    assert "过期" in snapshot.answer("TEST-1 价格", now + timedelta(days=2))
    assert "时间异常" in snapshot.answer("TEST-1 价格", now - timedelta(days=1))
    assert "唯一匹配" in snapshot.answer("TEST-12 价格", now)
    snapshot.products.append(snapshot.products[0].model_copy(update={"code": "TEST-2"}))
    assert "唯一匹配" in snapshot.answer("虚构商品 价格", now)


@pytest.mark.parametrize(
    "url", ["http://127.0.0.1:8000/api/v1/chat", "https://external.example/api/v1/jiahui/query"]
)
def test_rag_cannot_target_generic_agent_or_remote_host(tmp_path, url):
    with pytest.raises(ValueError, match="只读"):
        Assistant(tmp_path, [], rag_url=url)

"""Read-only RAG endpoint must never enter the commerce agent graph."""

from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import FastAPI

from app.api.routes.jiahui import router


def test_readonly_route_is_registered_in_existing_app():
    from app.config.settings import Settings
    from app.main import create_app

    app = create_app(Settings(app_env="testing"))
    assert "/api/v1/jiahui/query" in {route.path for route in app.routes}


@pytest.mark.asyncio
async def test_rag_requires_auth_and_separate_dataset(tmp_path, monkeypatch):
    knowledge = tmp_path / "jiahui-knowledge"
    knowledge.mkdir()
    (knowledge / "test.md").write_text("仅为自动测试，不是公司资料")
    monkeypatch.setenv("JIAHUI_RAG_TOKEN", "r" * 40)
    chunk = SimpleNamespace(
        document_id="d", title="测试资料", chunk_id="c", section="1", content="自动测试专用资料"
    )
    retriever = SimpleNamespace(retrieve=AsyncMock(return_value=[chunk]))
    app = FastAPI()
    app.state.container = SimpleNamespace(
        settings=SimpleNamespace(knowledge_dir=str(knowledge)), retriever=retriever
    )
    app.include_router(router)
    headers = {"Authorization": "Bearer " + "r" * 40}
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app), base_url="http://local"
    ) as client:
        assert (await client.post("/jiahui/query", json={"message": "规格"})).status_code == 401
        assert (
            await client.post("/jiahui/query", json={"message": "规格"}, headers=headers)
        ).status_code == 409
        monkeypatch.setenv("JIAHUI_KNOWLEDGE_DIR", str(knowledge))
        result = await client.post("/jiahui/query", json={"message": "规格"}, headers=headers)
        assert result.status_code == 200
        assert result.json()["citations"][0]["chunk_id"] == "c"
        assert "自动测试专用资料" in result.json()["answer"]
        retriever.retrieve.reset_mock()
        result = await client.post("/jiahui/query", json={"message": "库存价格"}, headers=headers)
        assert result.json()["citations"] == []
        retriever.retrieve.assert_not_called()
        app.state.container.settings.knowledge_dir = "knowledge"
        assert (
            await client.post("/jiahui/query", json={"message": "规格"}, headers=headers)
        ).status_code == 409

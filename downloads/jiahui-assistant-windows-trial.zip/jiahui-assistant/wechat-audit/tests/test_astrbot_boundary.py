"""Exercise the plugin against API-shaped test doubles; not a real adapter test."""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType, SimpleNamespace
from unittest.mock import AsyncMock, Mock

import httpx
import pytest


@pytest.fixture
def plugin(monkeypatch):
    class Plain:
        def __init__(self, text):
            self.text = text

    class At:
        def __init__(self, qq):
            self.qq = qq

    class AtAll(At):
        pass

    class Image:
        async def convert_to_file_path(self):
            return "/staged/test.png"

    class Star:
        def __init__(self, context):
            pass

    modules = {
        "astrbot": {},
        "astrbot.api": {"AstrBotConfig": dict},
        "astrbot.api.event": {
            "AstrMessageEvent": object,
            "filter": SimpleNamespace(
                EventMessageType=SimpleNamespace(ALL="all"),
                event_message_type=lambda *args, **kwargs: lambda f: f,
            ),
        },
        "astrbot.api.star": {
            "Context": object,
            "Star": Star,
            "register": lambda *args: lambda c: c,
        },
        "astrbot.api.message_components": {
            "At": At,
            "AtAll": AtAll,
            "Plain": Plain,
            "Image": Image,
        },
    }
    for name, values in modules.items():
        module = ModuleType(name)
        module.__dict__.update(values)
        monkeypatch.setitem(sys.modules, name, module)
    path = Path(__file__).resolve().parents[2] / "astrbot_plugin_jiahui/main.py"
    spec = importlib.util.spec_from_file_location("jiahui_plugin_test", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sent = []

    def transport(request):
        sent.append(__import__("json").loads(request.content))
        return httpx.Response(200, json={"reply": "测试响应"})

    original = httpx.AsyncClient
    monkeypatch.setattr(
        module.httpx,
        "AsyncClient",
        lambda **kw: original(transport=httpx.MockTransport(transport), **kw),
    )
    instance = module.JiahuiPlugin(
        None, {"platform_id": "wx", "group_id": "g", "gateway_token": "a" * 40, "enabled": True}
    )

    def event(parts, group="g", sender="member", platform="wx"):
        return SimpleNamespace(
            get_platform_id=lambda: platform,
            get_group_id=lambda: group,
            get_self_id=lambda: "bot",
            get_sender_id=lambda: sender,
            get_messages=lambda: parts,
            message_obj=SimpleNamespace(message_id="m1"),
            stop_event=Mock(),
            plain_result=lambda x: x,
            send=AsyncMock(),
        )

    return instance, sent, event, Plain, At, AtAll, Image


@pytest.mark.asyncio
async def test_private_other_group_self_are_stopped_without_backend(plugin):
    instance, sent, event, Plain, At, _, _ = plugin
    for e in [
        event([Plain("测试"), At("bot")], group=""),
        event([Plain("测试"), At("bot")], group="other"),
        event([Plain("测试"), At("bot")], sender="bot"),
    ]:
        await instance.receive(e)
        e.send.assert_not_called()
        e.stop_event.assert_called_once()
    assert sent == []


@pytest.mark.asyncio
async def test_visible_at_and_at_all_are_not_real_target_mentions(plugin):
    instance, sent, event, Plain, At, AtAll, _ = plugin
    for parts in [
        [Plain("@bot 测试")],
        [AtAll("bot"), Plain("测试")],
        [At("other"), Plain("测试")],
        [At("bot"), Plain("测试")],
    ]:
        e = event(parts)
        await instance.receive(e)
        e.send.assert_awaited_once()
    assert [x["mentioned"] for x in sent] == [False, False, False, True]
    assert sent[-1]["text"] == "测试"


@pytest.mark.asyncio
async def test_gateway_must_be_loopback_and_disabled_plugin_stays_silent(plugin):
    instance, sent, event, Plain, At, _, _ = plugin
    e = event([At("bot"), Plain("测试")])
    instance.config["gateway_url"] = "https://example.com"
    await instance.receive(e)
    instance.config["enabled"] = False
    await instance.receive(e)
    e.send.assert_not_called()
    assert sent == []

@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist "wechat-audit\.assistant-venv\Scripts\python.exe" (
  py -3.12 -m venv wechat-audit\.assistant-venv
  if errorlevel 1 goto :failed
)
wechat-audit\.assistant-venv\Scripts\python.exe -m pip install --require-hashes -r wechat-audit\assistant-windows.lock.txt
if errorlevel 1 goto :failed
set "PYTHONPATH=%CD%\wechat-audit"
echo 控制台：在本机浏览器打开 http://127.0.0.1:18960
wechat-audit\.assistant-venv\Scripts\python.exe -m jiahui_assistant.server
if errorlevel 1 goto :failed
exit /b 0
:failed
echo 启动失败，请保留上方错误信息。不要发送密钥或整个数据目录。
pause
exit /b 1

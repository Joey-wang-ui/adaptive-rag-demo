# 嘉惠业务助手 · Windows 试运行版

这是软件试运行交付，**不是已经接通普通微信群的上线版本**。现有 AstrBot 官方个人微信适配器不能据此认定可接普通微信群。代码未包含可用性未经验证的协议服务，也没有默认启用原 Windows 微信界面发送模块。

## 你现在只做一步

在准备试运行的 Windows 设备上，把完整压缩包解压到较短路径（例如 `C:\jiahui-assistant`），双击根目录 **`start-jiahui-assistant.cmd`**。需要已安装 Python 3.12；首次运行会安装本地 OCR 和服务依赖，需要联网。无需安装本地大语言模型、无需 GPU，也不需要先填 DeepSeek Key。

**成功标志：**启动窗口显示“嘉惠业务助手控制台已启动”，在该 Windows 设备浏览器中打开 `http://127.0.0.1:18960` 能看到中文控制台。窗口保持打开；关闭窗口后服务停止。这只证明本机服务启动，不证明微信接通。Windows 安装使用 `assistant-windows.lock.txt` 锁定间接依赖并校验包哈希；该文件由现有 `requirements.txt` 生成。

复制本机 `wechat-audit/data/assistant/gateway-token.txt` 的令牌到控制台，点“读取状态”。不要把令牌、DeepSeek Key 或整个数据目录发送到聊天。控制台默认关闭消息处理。控制台的 DeepSeek 设置可安全填写到本机文件；保存不会进行 API 调用。首次真实审核才会产生模型用量。

如果 Windows 提示缺少运行库或安装失败，保留错误内容并去除密钥后再诊断；不要跳过 TLS、包校验或盲目升级原项目依赖。Windows 启动脚本尚需在实际 Windows 上验证；开发环境已验证 Linux 安装与 Windows wheel 可获取性。

## 组成与运行位置

```text
普通微信群（接入端待实机验证）
        ↓ 真实群ID / @元数据 / 消息ID / 图片文件
AstrBot 4.29.3 + astrbot_plugin_jiahui
        ↓ 同机 loopback + 私有令牌
嘉惠网关 / 中文控制台
        ├─ RapidOCR → DeepSeek 字段提取 → Decimal 审单
        ├─ 现有 RAG 后端的专用只读检索接口 → 来源节选
        └─ 有来源和更新时间的价格/库存查询副本
```

首版 AstrBot 与网关应在同一台专用 Windows 设备上原生运行、使用不同 Python 环境。不要把一个放 Docker、另一个放宿主机后仍使用 `127.0.0.1` 或 Windows 文件路径；跨容器/跨主机文件与鉴权没有在此版实现。控制台和网关都只监听本机，不需要开放公网端口。

`wechat-audit` 原 OpenClaw 私聊程序仍保留，但不参与新 AstrBot 路径。原 Windows `group_runtime.py` 的界面发送也不会由新启动器运行。新插件本身不操作鼠标键盘；最终能否避免客户端操作取决于仍待选定的微信接入端。

## AstrBot 安装与插件接入（微信传输确定后执行）

不要为了接插件先购买所谓协议授权或降级到旧版 AstrBot。AstrBot 开源许可为 AGPL-3.0；分发 AstrBot 或修改版本时遵守其许可证，本包不捆绑第三方框架代码。

1. 按 AstrBot 官方 Windows 文档安装独立实例，版本验证基线为 **4.29.3**。此步骤不由本启动器自动完成。参考：https://github.com/AstrBotDevs/AstrBot/tree/master/docs/zh/deploy/astrbot 。
2. 将本包的 `astrbot_plugin_jiahui` 文件夹复制到 AstrBot 的 `data/plugins/` 下；已有同名文件夹先备份。或使用单独提供的插件 ZIP，按 AstrBot 的本地插件安装入口导入。重载插件，确认能看到“嘉惠业务助手”。插件不是适配器，不会凭空获得普通微信群权限。
3. 使用专用实例/配置文件，关闭通用 LLM 自动回复、主动回复及无关插件；避免其他插件在本插件前回复。启用插件并填写**真实平台实例 ID、唯一测试群 ID**与网关令牌，不能填群名。两个控制台都必须填写一致的 ID。没有群事件、真实 `At` 和机器人自身身份的接入端不能通过验收。
4. 本机设置 `JIAHUI_MEDIA_ROOTS` 为 AstrBot 实际图片落地目录后重新启动网关。Windows 多个目录使用 `;` 分隔。例如在 CMD 中执行：

   ```cmd
   set "JIAHUI_MEDIA_ROOTS=C:\AstrBot\data\temp"
   start-jiahui-assistant.cmd
   ```

   示例目录需要替换成你的真实路径。目录不匹配时会拒绝读取图片，不能通过允许整个磁盘来绕过。

## 必须逐关验收

### 1. 普通微信群文字

选择无客户资料的指定测试群。控制台阶段选“群内 @ 回复固定文字”，填好真实 ID 后启用；插件图片接收保持关闭。由另一位群成员在微信中选择机器人完成**真实 @**，发送 `测试`。

成功标志：指定群只回复一条“测试成功”。普通聊天、私聊、其他群、文字粘贴的 `@昵称`、机器人自己的回复均不触发。只有实际看到回群结果后，才能勾选“文字链路通过”。控制台里的“已处理请求”不代表发送已送达。

### 2. 单据图片原图

开启插件“图片接收”，控制台切换“图片测试”。真实 @ 并发送一张合成测试单据原图。服务返回尺寸、字节数、SHA256，不调用模型。

与发送端原文件核对，例如 Windows PowerShell `Get-FileHash -Algorithm SHA256 你的测试图片路径`。原文件完全一致时 hash 应相同；如果平台重编码或压缩，不能当作原文件直通，需要继续核查图像质量及协议原图能力。只有确认原图链路后才勾选“原图通过”。此阶段不要发送真实客户敏感资料。

### 3. 审单

在本机控制台填写 DeepSeek 官方 Key，切到业务模式。先发送虚构订单文字或图片，再真实 @ 并发送 `审核`；也可同一条 `审核` 后附正文或图片。无需固定“订单/出货单”标签。

- 默认仅关联同一发送者最近10分钟的材料，每批最多4份，每份最多30行。超出不会偷偷截断后给出通过结论；可点“清空待审材料”后重新分批。
- 只有一份单据时检查行金额、总计、重复项、缺失信息；不推测成交价是否正确。
- 两份单据只有客户和明确关联订单号一致时才自动比对；缺少关联就分别自查。
- 成功提取字段缓存、批次完成记录保留到 SQLite，重启后仍可去重；失败材料可以通过新的 @审核请求重试，不重复提取已成功部分。材料过期、清空后无法在原批次上继续补图。
- 已成功批次重复审核静默。回群发送结果不确定时不自动补发，避免循环；检查微信后人工处理。
- 无批准发货命令、不调用库存/财务写入、不自动跨员工配单。原私聊流程的人工确认命令未暴露到此网关。
- “停止新任务”立即阻止新任务；已经进入模型/发送环节的任务可能完成，不能撤回已发消息。**Esc 全局急停未实现。**窗口关闭后服务停止，启停状态会保留。

## 嘉惠产品与规则知识库

产品目录 PDF 尚未收到，公司规则也未导入，不能用原电商示例资料冒充嘉惠知识库。控制台的“知识库验收”默认不勾选。

复用现有 RAG 检索器，不复制一套知识库实现。新增只读端点 `/api/v1/jiahui/query` 只返回检索原文节选与来源，不进入原电商 Agent 工具执行流程，也不生成无来源业务答案。

接到真实资料后：将经过检查的内容放入**独立** `jiahui-knowledge` 目录（不使用原 `knowledge` 目录）；沿用项目的解析、切分和索引流程。PDF 排版和扫描件解析仍需逐页验证。

RAG 后端设置 `KNOWLEDGE_DIR`、`JIAHUI_KNOWLEDGE_DIR` 为这个独立目录，并设置私有 `JIAHUI_RAG_TOKEN`（至少32字符）。网关设置同一令牌和 `JIAHUI_RAG_URL=http://127.0.0.1:8000/api/v1/jiahui/query`，端口以实际 RAG 服务为准。不要配置通用 `/chat` 端点。索引及来源验收通过后再打开知识库开关。

## 价格与库存

不依据目录或模型记忆猜测。控制台可以导入从真实业务系统导出的**只读查询副本**，没有到 ERP 的写入连接。

JSON 结构如下（这里全是格式占位，不是嘉惠业务数据，不能直接当作有效报价）：

```text
{
  "updated_at": "带时区的真实更新时间，例如 ISO 8601 +08:00",
  "source": "真实业务数据来源/版本",
  "products": [{
    "code": "真实商品编码", "name": "真实名称", "specification": "真实规格",
    "unit_price": null, "price_unit": "",
    "stock": null, "stock_unit": ""
  }]
}
```

价格和库存数字使用十进制字符串；不知道的字段保留 null，不得补造。商品编码不可重复。超过24小时、未来异常时间、无时区或不能唯一匹配时不报价。查询示例为 `@机器人 查询 商品编码 库存`，答复附来源和更新时间。此版是手动导入副本，不是实时库存接口。

## 文件、费用与保管

- 启动入口：`start-jiahui-assistant.cmd`。
- 本机控制台：`wechat-audit/jiahui_assistant/console.html`。
- 插件：`astrbot_plugin_jiahui/`，不包含微信协议服务。
- 数据：`wechat-audit/data/assistant/`，包含令牌、可选模型 Key、SQLite、待审图片和只读业务副本，不要上传 Git 或发到群里。Windows 应放在仅本人可访问的用户目录；密钥是本机文件保存，不是系统凭据保险库。
- “清空待审材料”删除待审记录及本模块缓存图片，保留完成批次去重记录。原微信和 AstrBot 自己的缓存需分别管理。
- DeepSeek 审核按实际 API 用量收费，本地 OCR 不调用收费 OCR API。服务器、专用设备和可能的第三方微信服务费用尚未确定，不承诺账号零风险。
- 成品软件未控制你的日常微信窗口；现有 Windows 第三方群接入路径仍需兼容性实测，不能因本包测试通过就视为可用。

## Linux 开发与验证

```bash
python3.12 -m venv .venv-jiahui
.venv-jiahui/bin/python -m pip install -r wechat-audit/requirements.txt
PYTHONPATH=wechat-audit .venv-jiahui/bin/python -m jiahui_assistant.server
```

开发测试还需要根项目依赖和 pytest/pytest-asyncio：

```bash
python -m pip install -e .
python -m pip install pytest pytest-asyncio
PYTHONPATH=wechat-audit python -m pytest tests wechat-audit/tests -q
node wechat-audit/tests/plugin.test.mjs
```

不要把本机浏览器地址当成公开网站地址。源码和插件包尚未推送或发布到 GitHub；用户发布与真实微信验收需要单独完成。

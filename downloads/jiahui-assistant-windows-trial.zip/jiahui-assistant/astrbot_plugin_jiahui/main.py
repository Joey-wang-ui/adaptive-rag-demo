"""AstrBot boundary: real mentions, explicit platform scope, local gateway only."""

from urllib.parse import urlsplit

import httpx
from astrbot.api import AstrBotConfig
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import At, AtAll, Image, Plain
from astrbot.api.star import Context, Star, register


@register("jiahui", "嘉惠", "嘉惠审单与知识查询网关", "0.1.0")
class JiahuiPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config

    @filter.event_message_type(filter.EventMessageType.ALL, priority=100)
    async def receive(self, event: AstrMessageEvent):
        platform = event.get_platform_id()
        if platform != self.config.get("platform_id", ""):
            return
        # Own this platform's replies. Private/unapproved sessions cannot fall through
        # to AstrBot's generic model agent. Use a dedicated AstrBot instance/profile.
        event.stop_event()
        group = event.get_group_id()
        own = str(event.get_self_id())
        if (
            not self.config.get("enabled", False)
            or not group
            or group != self.config.get("group_id", "")
            or str(event.get_sender_id()) == own
        ):
            return
        components = event.get_messages()
        mentioned = any(
            isinstance(part, At) and not isinstance(part, AtAll) and str(part.qq) == own
            for part in components
        )
        text = "".join(part.text for part in components if isinstance(part, Plain)).strip()
        if text.startswith("【嘉惠业务助手】"):
            return
        message_id = str(event.message_obj.message_id or "")
        if not message_id:
            return
        url = self.config.get("gateway_url", "http://127.0.0.1:18960").rstrip("/")
        parsed = urlsplit(url)
        if (
            parsed.scheme != "http"
            or parsed.hostname not in {"127.0.0.1", "localhost", "::1"}
            or parsed.username
            or parsed.password
            or parsed.path
            or parsed.query
            or parsed.fragment
        ):
            return
        token = self.config.get("gateway_token", "")
        if len(token) < 32:
            return
        image_parts = [part for part in components if isinstance(part, Image)]
        if len(image_parts) > 4:
            if mentioned:
                await event.send(
                    event.plain_result("【嘉惠业务助手】同一条最多4张图片，未进行审核。")
                )
            return
        try:
            images = []
            if self.config.get("receive_images", False):
                for part in components:
                    if isinstance(part, Image):
                        images.append(await part.convert_to_file_path())
            async with httpx.AsyncClient(timeout=180, trust_env=False) as client:
                response = await client.post(
                    url + "/message",
                    headers={"Authorization": "Bearer " + token},
                    json={
                        "platform": platform,
                        "group": group,
                        "sender": str(event.get_sender_id()),
                        "self_id": own,
                        "message_id": message_id,
                        "mentioned": mentioned,
                        "text": text,
                        "images": images,
                    },
                )
                response.raise_for_status()
                reply = response.json().get("reply")
        except Exception:
            # Never route a failure to generic chat or leak upstream error bodies.
            reply = (
                "【嘉惠业务助手】本机服务未完成处理，未批准发货。请检查控制台后重新 @审核。"
                if mentioned
                else None
            )
        if reply:
            # A stopped event skips the response pipeline. Send directly exactly once;
            # do not retry an uncertain send or fall through to the generic agent.
            await event.send(event.plain_result(reply))

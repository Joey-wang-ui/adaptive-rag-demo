"""Offline evaluation package."""

"""Read-only Jiahui retrieval endpoint: no agent graph, tools or business writes."""

import hmac
import os
import re
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

router = APIRouter(prefix="/jiahui", tags=["jiahui"])


class Question(BaseModel):
    message: str = Field(min_length=1, max_length=4000)


@router.post("/query")
async def query(payload: Question, request: Request) -> dict:
    """Return cited source excerpts from an explicitly approved, separate knowledge directory."""
    token = os.environ.get("JIAHUI_RAG_TOKEN", "")
    if len(token) < 32 or not hmac.compare_digest(
        request.headers.get("authorization", ""), "Bearer " + token
    ):
        raise HTTPException(401, "Unauthorized")
    container = request.app.state.container
    approved = os.environ.get("JIAHUI_KNOWLEDGE_DIR", "")
    actual = Path(container.settings.knowledge_dir).resolve()
    # Do not activate against the original commerce examples, even by a console checkbox.
    if (
        not approved
        or actual != Path(approved).resolve()
        or actual == Path("knowledge").resolve()
        or not actual.is_dir()
        or not any(actual.iterdir())
    ):
        raise HTTPException(409, "独立嘉惠知识库尚未配置或为空。")
    if re.search(r"价格|单价|报价|库存|现货|多少钱|有货", payload.message):
        return {"answer": "未接入带更新时间的价格和库存数据，不提供推测。", "citations": []}
    chunks = await container.retriever.retrieve(payload.message, top_k=3)
    if not chunks:
        return {"answer": "没有检索到可引用资料。", "citations": []}
    # Extractive output keeps this endpoint read-only and never invokes the commerce agent.
    return {
        "answer": "以下是检索到的嘉惠资料原文节选，请结合问题核对：\n\n"
        + "\n\n".join(
            f"[{index}] {chunk.title}\n{chunk.content[:1200]}"
            for index, chunk in enumerate(chunks, 1)
        ),
        "citations": [
            {
                "document_id": chunk.document_id,
                "title": chunk.title,
                "chunk_id": chunk.chunk_id,
                "section": chunk.section,
            }
            for chunk in chunks
        ],
    }

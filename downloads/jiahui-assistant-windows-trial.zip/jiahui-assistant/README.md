---
title: Adaptive RAG Demo
emoji: 💬
colorFrom: green
colorTo: blue
sdk: docker
app_port: 8000
pinned: false
license: mit
---

## 本仓库：客服演示与微信审单试用

**微信群审单桌面界面：** 双击 **`open-group-audit.cmd`**，填写群名、昵称和 Key，点击检测 / 启动 / 停止。v0.4 支持可选的自己触发测试，并静默跳过已完成的同一批审核。支持订单文字、图片和图文混合（1～4份）后 @审核，也可首行 @审核、换行粘贴正文；只有出货单也能自查，不要求标签编号。软件内可改审核偏好并接其他 OpenAI 兼容 LLM。打开软件不自动回复。需要已安装的 Python 3.12；独立 Windows 软件包由仓库 Actions 构建。详见 [桌面版说明](wechat-audit/DESKTOP.md)。

**指定微信群审单（实验适配器）：** 先运行 **`setup-group-audit.cmd`** 检测指定群文字读取，再运行 **`start-group-audit.cmd`** 启用该群的 @ 审核与自动回群。复用第三方微信收发底层和现有本地 OCR/DeepSeek/金额核对，不需要完整聊天机器人。首次只填群名、昵称和 API Key。完整配置与图片关联规则见 [GROUP-AUDIT.md](wechat-audit/GROUP-AUDIT.md)。**微信 4.2.0.6 尚未实测兼容。**

**微信 4.2 群消息读取检查：** 双击 **`check-wechat-groups.cmd`**，在自己的 Windows 上对一个手动打开的测试群做只读实机检测；不需要 API Key。这个旧检查脚本只读取可见界面，不获取原图或自动审单，也未确认兼容 4.2.0.6。详见 [群聊检查说明](wechat-audit/GROUPS.md)。

**微信私聊发货前审单（新增试运行版）：** 完整解压后双击 **`start-wechat-audit.cmd`**，自动安装固定版本 OpenClaw、腾讯官方微信插件和小型 OCR 组件，复用或隐藏输入 DeepSeek Key，检查后扫码连接微信。发送确认订单和出货单图片，机器人回复商品、规格、数量、成交价和金额差异，人工确认绑定具体版本。当前是单操作者辅助审单，不支持直接进普通微信群、分岗审批或库存联动。详见 [微信审单启动与使用说明](wechat-audit/README.md)。

**使用 DeepSeek 官方 API：** 双击 **`start-api.cmd`**，在本机终端隐藏输入 API Key（输入时不显示字符），或直接回车复用环境变量 / `.env` 中已有的 `DEEPSEEK_API_KEY`。密钥不写入文件或命令参数；先通过一次最多 64 个输出 token 的真实 JSON 生成检查，再启动聊天网页。无需 Ollama 或模型下载。API 按供应商规则计费，需账号有可用余额/额度；一次聊天可能多次调用模型。详见 [API 启动说明](DEPLOYMENT.md#deepseek-官方-api-启动)。

**推荐：Windows 自动安装并运行本地模型。** 下载并完整解压本仓库 ZIP，双击 **`install-and-run.cmd`**。它会复用已安装的软件，通过 WinGet 安装缺失的 Python 3.12、Node.js LTS 和 Ollama，安装项目依赖，下载或续传官方 Qwen2.5 3B，校验文件并测试真实生成，然后启动聊天网页。软件安装可能需要 Windows 授权；缺少 WinGet 或网络不可用时会明确停止。保留窗口，按 Ctrl+C 停止；以后仍双击同一文件。详见 [自动安装说明](DEPLOYMENT.md#windows-自动安装并运行推荐)。

**Windows 本地启动：** 安装 Python 3.12 和 Node.js 24 LTS 后，下载并完整解压本仓库 ZIP，双击根目录的 `start-local.cmd`。它会创建虚拟环境、安装依赖、构建网页、准备隔离的演示订单并自动打开浏览器；首次运行需要联网下载依赖。无需激活环境、修改 PowerShell 执行策略或安装 Docker。运行时保留命令窗口，按 Ctrl+C 停止。详见 [本地启动说明](DEPLOYMENT.md#windows-本地启动)。

**使用真实本地模型：** 先安装 [Ollama Windows](https://ollama.com/download/windows)，然后双击 `start-local-model.cmd`。默认准备 `qwen2.5:3b`（模型下载约 2GB，运行还需额外内存），先测试真实 JSON 生成，再启动网页。无需模型 API Key。原 `start-local.cmd` 保持原有配置/离线路径。详见 [Ollama 说明](DEPLOYMENT.md#ollama-本地生成模型)。

基于 [JEen-wang/Adaptive-rag](https://github.com/JEen-wang/Adaptive-rag)，保留原项目历史和 MIT 许可证。
增加了网页右下角聊天弹窗，以及用于 Hugging Face Docker Spaces 的轻量离线部署配置。

当前采用 Windows 本地启动。Render 和 Hugging Face 配置保留为备选，账号可能要求绑卡或付费，不保证免费托管可用。代码下载：[GitHub ZIP](https://github.com/Joey-wang-ui/adaptive-rag-demo/archive/refs/heads/main.zip)。

部署步骤见 [DEPLOYMENT.md](DEPLOYMENT.md)。根目录 `Dockerfile` 使用轻量离线配置；原模型镜像配置保存在 `Dockerfile.models`。Render 配置作为备选保留。
容器与原 `start-local.cmd` 在未配置生成模型时使用检索原文节选；`install-and-run.cmd` 则必须通过真实 Ollama 生成检查才启动网页。上述轻量启动器仍不使用真实语义 Embedding 或 Cross-Encoder。下面保留的原项目模型评测结果，不代表本演示的效果。
此演示尚无用户认证，仅供个人使用；不要输入隐私信息或连接真实业务数据库。SQLite 在容器内，实例重建后可能丢失。

---

<h1 align="center">Adaptive RAG · 电商客服工作流</h1>

<p align="center"><strong>针对基于 FAQ 的传统客服系统长尾问题命中率极低，人工介入成本高的问题和常规 RAG 多跳推理能力差，幻觉问题严重的痛点设计并实现了基于 Adaptive-RAG 的多智能体电商客服系统。</strong></p>
<p align="center">FastAPI × LangGraph × 混合检索 · API、流式对话与 ChatGPT 风格 Web 工作台</p>

<p align="center">
  <a href="https://github.com/JEen-wang/Adaptive-rag/actions/workflows/ci.yml"><img alt="CI" src="https://github.com/JEen-wang/Adaptive-rag/actions/workflows/ci.yml/badge.svg"></a>
  <a href="LICENSE"><img alt="License: MIT" src="https://img.shields.io/badge/license-MIT-22c55e"></a>
  <img alt="Python 3.11+" src="https://img.shields.io/badge/Python-3.11%2B-3776AB?logo=python&logoColor=white">
  <img alt="FastAPI" src="https://img.shields.io/badge/API-FastAPI-009688?logo=fastapi&logoColor=white">
  <img alt="React and TypeScript" src="https://img.shields.io/badge/Web-React%20%2B%20TypeScript-149eca?logo=react&logoColor=white">
</p>

<p align="center">
  <a href="#overview">项目亮点</a> · <a href="#quickstart">快速开始</a> ·
  <a href="#architecture">系统架构</a> · <a href="#evaluation">实测结果</a> ·
  <a href="#resume">简历写法</a> ·
  <a href="#docs">完整文档</a> · <a href="#limitations">使用边界</a> ·
  <a href="#roadmap">后续路线图</a>
</p>

---

<a id="overview"></a>

## ✨ 一眼看懂

> **Adaptive RAG** 的核心决策是：这个问题需要直接回答、检索一条证据、交叉核对多条证据、调用业务工具，还是拒绝处理？

电商客服里的问题跨度很大。「你好」无需查知识库；退货政策需要可靠出处；「定制商品超过七天但有质量问题」要同时判断定制、时效与质量例外；取消订单则必须检查订单状态、权限与确认。项目用明确的路由策略处理这些差异，避免把所有输入都塞进同一条向量检索链路。

| 能力 | 你能看到什么 | 关键实现 |
|:---|:---|:---|
| 🧭 **按复杂度路由** | 每次回答带有 `strategy`，便于追踪实际路径 | [Graph 与节点](app/agents/graph.py) · [策略枚举](app/core/enums.py) |
| 🔎 **有出处的检索** | BM25、稠密向量、RRF 融合与精排；回答可带 `citations` | [检索模块](app/retrieval/) |
| 🧩 **多跳与自纠错** | 复合问题拆分检索，答案经过忠实度检查 | [智能体节点](app/agents/nodes/) |
| 🛡️ **人工确认** | 高风险写操作先返回 `pending_action`，确认后才执行 | [工具与权限](app/tools/) |
| 💬 **Web 对话工作台** | 流式显示、引用、本地会话搜索、深色模式与确认卡片 | [前端](frontend/) |
| 📈 **可测可观测** | 离线评测、回归测试、结构化日志与 Prometheus 指标 | [评测](eval/) · [可观测性](app/observability/) |

### 五条处理路径

| 策略 | 适合的问题 | 处理方式 |
|:---:|:---|:---|
| `DIRECT` | 问候、闲聊 | 直接生成，不做知识检索 |
| `SINGLE` | 单一政策问题 | 一轮混合检索与精排 |
| `MULTI` | 多条件、跨条款问题 | 查询改写、多路检索与自纠错 |
| `AGENT` | 查询订单、物流或发起业务操作 | 规划后调用受权限约束的工具 |
| `REFUSE` | 越权、注入或证据不足 | 拒答或引导人工处理 |

> [!TIP]
> 第一次了解项目，可以先看[架构图](#architecture)，再按[快速开始](#quickstart)提问。想看每条路径怎样落到代码，读[智能体与工具](docs/05-agents-and-tools.md)。

<a id="quickstart"></a>

## 🚀 快速开始

默认使用 SQLite 和内存检索组件，不要求先部署 Redis 或 Qdrant。需要 **Python 3.11+**；Web 开发另需满足[前端 Node.js 要求](frontend/README.md)。

### 1. 安装并启动 API

```bash
git clone https://github.com/JEen-wang/Adaptive-rag.git
cd Adaptive-rag
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
cp .env.example .env
uvicorn app.asgi:app --reload --port 8000
```

Windows PowerShell 激活虚拟环境可使用 `.venv\Scripts\Activate.ps1`。首次启用本地 Embedding / Cross-Encoder 时可能需要下载模型；需要完整的本地精排依赖可安装 `pip install -e ".[rerank]"`。更多选项见[配置参考](docs/07-configuration.md)。

`.env` 中的 `DEEPSEEK_API_KEY` 可留空：此时系统进入离线演示模式，展示检索原文或可核对的订单状态，不会假装生成完整答案。要体验生成式回答，需要配置可用的 DeepSeek 密钥。**不要提交 `.env` 或密钥。**

### 2. 发送第一条消息

```bash
curl -s http://127.0.0.1:8000/api/v1/health
curl -s http://127.0.0.1:8000/api/v1/chat \
  -H 'content-type: application/json' \
  -d '{"message":"定制马克杯过了七天，但有质量问题还能退吗？","user_id":"u_demo"}'
```

响应包含 `answer`、`strategy`、`trace_id`，需要检索时还会带 `citations`。也可以运行 `python -m app.cli` 进入终端对话；流式接口为 `POST /api/v1/chat/stream`，完整字段见 [API 参考](docs/06-api-reference.md)。

### 3. 打开 Web 工作台

保持 API 运行，另开终端：

```bash
cd frontend
npm ci
npm run dev
```

访问 **http://127.0.0.1:5173**。开发服务器会把 `/api` 代理到本地 FastAPI。执行 `npm run build` 后，FastAPI 检测到 `frontend/dist` 也会在根路径提供页面；Docker 镜像会自动构建前端。前端会话列表存于浏览器本地，详见[前端 README](frontend/README.md)。

<details>
<summary><strong>🧪 想体验订单工具与人工确认？展开查看演示数据步骤</strong></summary>

<br>

当前分支默认启动**不会自动写入**演示订单。先停止 API，在仓库根目录、已激活虚拟环境的终端执行：

```bash
python - <<'PY'
import asyncio
from app.config.settings import get_settings
from app.services.container import build_container

async def main():
    container = await build_container(get_settings(), seed=True)
    await container.aclose()

asyncio.run(main())
PY
```

然后重新启动 API。种子会为 `u_demo` 写入 `ORD10001`（已发货）、`ORD10002`（已签收）和 `ORD10003`（已支付未发货）。例如询问“取消订单 ORD10003”，系统先给出 `pending_action.action_id`；确认请求携带该 ID 后才执行。详见 [HITL 与幂等](docs/05-agents-and-tools.md)。

</details>

<a id="architecture"></a>

## 🏗️ 系统架构

```mermaid
flowchart LR
    U["用户 · Web / CLI / HTTP"] --> API["FastAPI · JSON / SSE"]
    API --> S["ChatService"]
    S --> G["LangGraph：护栏 → 意图 → 复杂度路由"]
    G --> D["DIRECT"]
    G --> R["SINGLE / MULTI"]
    G --> A["AGENT"]
    G --> F["REFUSE"]
    R --> H["BM25 + 向量 → RRF → 精排"]
    A --> T["权限校验 → 工具 → 人工确认"]
    D --> O["生成 / 忠实度检查"]
    H --> O
    T --> O
    F --> O
    O --> X["回答 + 引用 + trace_id"]
```

HTTP 层处理校验与序列化，`ChatService` 编排对话，Graph 决定路径，检索器与工具由容器装配。默认数据库为 SQLite；Redis、Qdrant 和远程模型按配置接入。完整的节点、降级路径和依赖关系见[架构与运行流程](docs/17-architecture-flow.md)。

<a id="evaluation"></a>

## 📊 实测结果与口径

下面的**检索与生成指标**来自 2026-08-22 的离线评测，具体数据集、模型与运行命令见 [`eval/MEASURED.md`](eval/MEASURED.md) 和[完整报告](docs/14-evaluation-report.md)。报告原始 JSON 未随仓库分发，复现时应以当前环境重新运行。

| 环节 | 样本与设置 | 结果 |
|:---|:---|:---|
| 意图识别 | 100 条，`intent_v3` + 歧义规则覆盖 | **100%**；纯模型结果并非 100% |
| BM25 稀疏检索 | 65 条政策问题 / 39 篇文档 | P@1 **76.9%** · R@3 **90.0%** |
| bge-small 稠密检索 | 同一检索集 | P@1 **83.1%** · R@3 **94.6%** |
| Hybrid + Cross-Encoder | 同一检索集 | P@1 **89.2%** · R@3 **97.7%** · MRR **0.94** |
| RAG + 自纠错生成 | 65 条，同模型裁判 | 忠实度 **100%** · 幻觉率 **0%** |
| 端到端 | 16 条 | 关键词命中 **9/11** · P50 **4.9s** · P95 **5.8s** |

> [!IMPORTANT]
> 这些是**指定离线集合与模型配置**下的测量值，不代表生产环境承诺。该集合上 RRF 与单独使用 bge-small 的检索数字相同，主要增益来自 Cross-Encoder；生成忠实度使用同模型裁判，可能偏乐观。不要把 `0%` 幻觉率理解为真实场景零错误。

CI 在 Python 3.11 / 3.12 上检查锁文件、Ruff、mypy 和 pytest；[查看工作流](.github/workflows/ci.yml)。本地可运行：

```bash
python -m pytest -q
python -m eval.runner --task retrieval
cd frontend && npm test && npm run build
```

<a id="resume"></a>

## 📝 简历写法

**基于 Adaptive-RAG 的电商客服**

**项目概述：** 针对基于 FAQ 的传统客服系统长尾问题命中率极低，人工介入成本高的问题和常规 RAG 多跳推理能力差，幻觉问题严重的痛点设计并实现了基于 Adaptive-RAG 的多智能体电商客服系统。

- **架构设计：** 基于 LangGraph 搭建核心状态机，规划器与执行器，统一接入 15 个核心工具，实现流式输出与指数退避+抖动重试；解析意图识别，采用 Prompt-template+DeepSeek v3 构建意图路由节点并通过 LLM 自主决策分解子任务并调用工具，自建 100 条测试 query 测试意图识别准确率达到 97%。

- **检索阶段：** FAQ、退货策略、配送说明等文档进行预处理、切分、向量化索引。基于 Adaptive-RAG 实现科学感知的逻辑路由，动态调度检索策略，并通过问题改写和混合检索，解决多跳问题。

- **检索优化：** 基于 Self-RAG 构建多轮检索策略，并利用 RRF 算法对多源异构检索结果进行融合与去重，随后调用 Cohere 模型进行重排序。

  **Precision 58%→85%，Recall 63%→91%，Faithfulness 54%→88%，幻觉率下降 62%。**

- **上下文压缩与记忆管理：** 针对长会话导致的 Token 冗余及成本问题，开发 128k Token 预算管理模块（滑动窗口 + 动态摘要）；实现 3 层压缩流水线，在上下文利用率在 50%~70% 时自动收紧工具结果体积，>85% 时触发 auto-compact，达到从轻量级截断到全量摘要逐级递进的渐进式压缩。

- **Skill + MCP 的可插拔能力体系：** 支持按需加载退货处理、订单跟踪、商品推荐等标准化技能流程，并将本地工具与远程 MCP 工具统一为 Function Calling 接口。

- **兜底与护栏机制：** 设计任务分解和工具执行层双向引入 Fallback 机制；部署查询边界、幻觉检测与自纠错重试机制，将幻觉率控制在 4% 以下。

> **仓库实现说明：** 上述文字按简历原文展示。当前代码未接入 Cohere API，实际使用轻量级 `BAAI/bge-small-zh-v1.5` 做向量检索、本地 `BAAI/bge-reranker-base` 做精排；所列简历指标与仓库的[实测报告](eval/MEASURED.md)口径不同。Cohere Rerank 试用 API 密钥有免费限额，正式 API 使用按量收费，详见 [Cohere 定价说明](https://cohere.com/pricing)。

<a id="docs"></a>

## 🗺️ 从哪里继续阅读

| 目标 | 推荐入口 |
|:---|:---|
| 跑通 API、CLI、Web 与 Docker | [快速开始](docs/02-getting-started.md) · [部署](docs/11-deployment.md) |
| 理解分层、Graph 与路由 | [架构](docs/03-architecture.md) · [Adaptive RAG](docs/04-adaptive-rag.md) |
| 看检索、精排、工具与 HITL | [解析与检索](docs/15-ingest-and-retrieval.md) · [智能体与工具](docs/05-agents-and-tools.md) |
| 查接口、配置、安全与可靠性 | [API](docs/06-api-reference.md) · [配置](docs/07-configuration.md) · [安全](docs/09-security.md) · [可靠性](docs/08-reliability.md) |
| 核对实验口径与数字 | [评测方法](docs/10-evaluation.md) · [原始数字说明](eval/MEASURED.md) |
| 系统学习 RAG 工程实践 | [12 部分教学文档](docs/tutorial/README.md) |
| 准备 Agent/RAG 面试 | [Chapter 1](docs/interview/chapter1.md) · [Chapter 2](docs/interview/chapter2.md) · [Chapter 3](docs/interview/chapter3.md) · [17 维度索引](docs/16-interview-bagu-map.md) |

完整索引见 [`docs/README.md`](docs/README.md)。源码可从 `app/asgi.py` → `app/services/chat_service.py` → `app/agents/graph.py` 开始读；Web 代码在 `frontend/src/`。

<details>
<summary><strong>📁 展开项目目录</strong></summary>

```text
app/
  api/            HTTP 路由、校验、SSE
  services/       ChatService、依赖容器、演示数据
  agents/         LangGraph 状态机与节点
  retrieval/      解析、切块、混合检索、精排与自纠错
  tools/          业务工具、注册表与权限
  repositories/   订单、会话与幂等
  providers/      生成、Embedding 与 Rerank
  guardrails/     注入、边界与忠实度检查
  memory/         上下文预算与压缩
  observability/  日志、指标与请求上下文
frontend/         React + TypeScript Web 工作台
knowledge/        政策文档
eval/             离线评测与口径
tests/            单元、集成与端到端测试
docs/             技术手册与教学文档
```

</details>

<a id="limitations"></a>

## ⚠️ 使用边界

这是可运行的工程示例，**目前不应直接面向不可信用户开放**：

- API 尚未认证请求中的 `user_id`；前端默认 `u_demo` 仅供本地演示。部署前应由可信服务端认证并绑定身份。
- 订单与物流来自本地仓储演示数据，没有连接真实承运商或支付网关。
- Web 会话列表保存在当前浏览器的 `localStorage`，清除站点数据或换设备后不会恢复。
- 知识库启动时全量 ingest，尚无增量删除接口；Embedding / 精排权重不可用时会降级，降级后的效果未单独评测。

更多实现边界与后续方向见[限制与路线图](docs/12-limitations.md)。

<a id="roadmap"></a>

## 🧭 后续完善与优化路线图

以下是基于当前代码整理的待办，**不是已经完成的功能**。先解决身份、会话和写操作的正确性，再改善知识库更新、响应速度与云端演示体验。

### 1. 上线前先补齐

| 优先级 | 改进项 | 目标与代码入口 |
|:---:|:---|:---|
| P0 | **身份与会话隔离** | 不再信任请求体中的 `user_id`；读取已有会话时校验所属用户，避免跨用户读取历史。[请求模型](app/schemas/chat.py) · [会话仓储](app/repositories/session_repository.py) |
| P0 | **云端部署边界** | 移除数据库、Redis、Qdrant 的公网端口映射和固定密码；只开放受控的 Web/API 入口。[Compose](docker-compose.yml) |
| P0 | **真正接入多轮记忆** | 回答生成目前只使用当前问题，初始摘要为空，压缩发生在回答之后；应把历史与摘要按预算送入生成、路由和规划。[对话服务](app/services/chat_service.py) · [生成节点](app/agents/nodes/generate.py) · [记忆节点](app/agents/nodes/memory.py) |
| P1 | **可靠的人工确认** | 待确认操作从进程内字典迁移到持久化存储，支持过期、一次性消费和多副本。[对话服务](app/services/chat_service.py) · [执行节点](app/agents/nodes/executor.py) |
| P1 | **准确呈现服务状态** | 区分 API 存活与模型、向量库就绪；Embedding 或精排降级时在接口和页面明确提示。[健康检查](app/api/routes/health.py) · [模型装配](app/services/container.py) |

### 2. 提升功能与体验

| 方向 | 改进项 | 预期效果 |
|:---|:---|:---|
| 知识库 | 增量入库、删除同步、文档版本与缓存失效；避免旧向量和旧引用残留。[入库](app/retrieval/ingest.py) · [向量库](app/retrieval/vector.py) | 政策更新后，检索结果与引用保持一致。 |
| 文档解析 | 在需要 PDF、Office、图片入库的镜像中安装解析依赖与系统包，并报告解析失败的文件。[解析器](app/retrieval/unstructured_parser.py) · [Dockerfile](Dockerfile) | 非 Markdown 文档不再被静默跳过。 |
| 响应体验 | 明确显示检索、生成、核验进度；当前 SSE 在答案核验完成后才分块输出。[SSE](app/services/chat_service.py) · [前端请求](frontend/src/lib/api.ts) | 用户能看懂等待发生在哪一步。 |
| 速度与成本 | 记录每个节点的耗时、调用次数和 Token 用量，为简单问题设置快速路径，为多跳检索设置预算。[工作流](app/agents/graph.py) · [指标](app/observability/metrics.py) | 减少不必要的模型调用。 |
| 首次演示 | 让首页示例问题与演示订单初始化保持一致，并提供一键准备演示数据的入口。[首页](frontend/src/App.tsx) · [种子数据](app/services/seed.py) | 打开页面即可验证订单与确认流程。 |
| 模型启动 | 预热本地 Embedding 与精排模型，持久化权重缓存，显示加载或降级状态。[Embedding](app/providers/embeddings.py) · [精排](app/providers/reranker.py) | 减少首问等待和重建后的重复下载。 |
| 前端会话 | 将仅存于 `localStorage` 的会话与服务端历史打通，并增加断线重连状态。[本地存储](frontend/src/lib/storage.ts) | 刷新、换设备后仍可继续对话。 |

### 3. 工程化与复杂改造

1. **数据库迁移：** 启动时使用 `create_all`，应改为部署时运行 Alembic，并验证升级和回滚。[数据库初始化](app/repositories/db.py)
2. **完整回归链路：** 在现有 Python CI 上补充前端测试、Docker 构建，以及覆盖问答、引用、订单查询、人工确认的端到端测试。[CI](.github/workflows/ci.yml)
3. **通用 MCP 与真实业务接入：** 当前远程工具通过固定 HTTP JSON 接口调用；若要对接通用 MCP 服务或真实订单、物流系统，还需处理能力发现、认证、权限、超时和审计。[MCP 适配器](app/mcp/runtime.py) · [业务工具](app/tools/)
4. **一致性设计：** 多轮摘要不能覆盖最新事实；写操作确认时要重新核对订单状态；知识库更新时 BM25、向量、缓存和引用应切到同一版本。这三处适合分别做设计和故障测试。

## ⭐ Star 统计

[![Star History Chart](https://api.star-history.com/svg?repos=JEen-wang/Adaptive-rag&type=Date)](https://www.star-history.com/?repos=JEen-wang%2FAdaptive-rag&type=date)

## 🤝 参与贡献

欢迎提交问题与改进。修改前建议先读[贡献指南](CONTRIBUTING.md)；提交代码时运行 Ruff、mypy、pytest，修改前端时运行 `npm test` 与 `npm run build`。请勿提交 `.env`、密钥、本地数据库或生成的评测报告。

## 📄 许可证

项目采用 [MIT License](LICENSE)。可在保留许可与版权声明的前提下使用、修改和分发。

---

<p align="center">
  <sub>从一个问题开始，沿着策略、证据、工具与指标追到代码。<br>
  指标口径以 <a href="eval/MEASURED.md">eval/MEASURED.md</a> 为准。</sub>
</p>
